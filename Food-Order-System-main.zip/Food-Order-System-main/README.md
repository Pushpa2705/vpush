# Food-Order-System-
Food Order System in java NetBeans.

Select categories , select checkbox , enter quantity and press Total button. 

Output :


![fo1](https://user-images.githubusercontent.com/106819662/196504053-5261a2ae-476b-4302-9c6a-c2adeb213858.png)


![fo2](https://user-images.githubusercontent.com/106819662/196504087-dd9a5a73-ed2e-4e79-b2af-1ab86967a601.png)
